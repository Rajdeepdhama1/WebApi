﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiDemo.Models
{
    public class Students
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public string Course { get; set; }
        public string Branch { get; set; }
        public string Section { get; set; }
        public int MobileNo { get; set; }
        public int RollNo { get; set; }
        public string CollegeName { get; set; }
        public string SchoolName { get; set; }
        public string City { get; set; }
    }
}
