﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using StudentData;
namespace ApiDemo.Controllers
{
    public class StudentsController : ApiController
    {
        public IEnumerable<Student> Get()
        {
            using (StudentDBEntities entities = new StudentDBEntities())
            {
                return entities.Students.ToList();
            }

        }
        public Student Get(int ID)
        {
            using (StudentDBEntities entities = new StudentDBEntities())
            {
                return entities.Students.FirstOrDefault(S => S.StudentID == ID);
            }

        }
    }
}
